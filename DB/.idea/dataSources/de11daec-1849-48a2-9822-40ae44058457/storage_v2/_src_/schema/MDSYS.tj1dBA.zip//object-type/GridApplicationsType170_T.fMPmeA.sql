create TYPE         "GridApplicationsType170_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","GridApplication" "GridApplication172_COLL")NOT FINAL INSTANTIABLE
/

