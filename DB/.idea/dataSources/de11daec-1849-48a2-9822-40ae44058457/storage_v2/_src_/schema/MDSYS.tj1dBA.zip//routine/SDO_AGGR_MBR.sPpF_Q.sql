create function SDO_Aggr_MBR wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
65 8d
0U3HMSZDAsKxzMGsc3qZfsXqZ1Mwg8eZgcfLCNL+XuefCNC/Wa6WGP4yniW4v4H+XKUyvUp0
PB301lPiqDX37HGenjXiqGs1P1QUlFN2VVXWcVWkhHGU5tYAc2iUZ88O3jx0phXKduE=
/

