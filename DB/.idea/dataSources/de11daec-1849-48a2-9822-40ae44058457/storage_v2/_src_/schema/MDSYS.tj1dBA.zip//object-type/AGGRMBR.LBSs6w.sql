create type AggrMBR AUTHID current_user as Object
(
  context mdsys.SDOAggr,
  static function odciaggregateinitialize(sctx OUT AggrMBR) return number,
  member function odciaggregateiterate(self IN OUT AggrMBR,
               geom IN mdsys.sdo_geometry) return number,
  member function odciaggregateterminate(self IN AggrMBR,
                                        returnValue OUT mdsys.sdo_geometry,
                                          flags IN number)
                     return number,
  member function odciaggregatemerge(self IN OUT AggrMBR,
                    valueB IN  AggrMBR) return number);
/

