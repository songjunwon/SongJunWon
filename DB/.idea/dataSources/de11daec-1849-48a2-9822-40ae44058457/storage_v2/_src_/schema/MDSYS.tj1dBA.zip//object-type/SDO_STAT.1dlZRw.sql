create TYPE sdo_stat wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
d
3d 69
c/lbb5uA+dlnpUpbm4c/amq5lWwwg5n0dLhcFtz60JbRoVbMuHQrpb+bwDLLzFClxyulmYEy
wLIlzLh0wDJGx+TkDlku9jmmSboviQ==
/

