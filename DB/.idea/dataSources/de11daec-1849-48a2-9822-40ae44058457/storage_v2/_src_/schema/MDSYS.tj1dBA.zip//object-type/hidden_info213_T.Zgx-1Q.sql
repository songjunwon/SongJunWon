create TYPE         "hidden_info213_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","field" "field215_COLL")FINAL INSTANTIABLE
/

