create function SDO_VERSION wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
b1 c2
EkpqEbvhrE3NFNCAIWM5nplFga8wg1xKLcvWfHSi2vjVNLNIXIiMy6h/bNO0jXlNdZu1qrNW
w/XaKRnaVVPAm2Zfp2NIGjxlDvFkl1PpLl53W2DWgqXV4nNzb3AO6t7xs1n6CHCemORkSsWZ
i6greay+uc5YWr23VrujmwP29R+m+9AdFySmUsuclskj0Q8=
/

