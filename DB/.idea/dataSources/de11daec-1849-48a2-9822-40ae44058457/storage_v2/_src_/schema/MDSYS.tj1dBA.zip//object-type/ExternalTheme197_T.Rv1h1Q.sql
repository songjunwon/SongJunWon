create TYPE         "ExternalTheme197_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","MapViewerTiles" "MapViewerTiles198_T","DigitalGlobeTiles" VARCHAR2(4000 CHAR))FINAL INSTANTIABLE
/

