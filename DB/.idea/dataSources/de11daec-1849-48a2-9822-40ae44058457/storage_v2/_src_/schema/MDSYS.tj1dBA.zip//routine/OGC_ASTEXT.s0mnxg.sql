create FUNCTION OGC_AsText(
  g ST_Geometry)
    RETURN VARCHAR2 IS
BEGIN
  RETURN g.GET_WKT();
END OGC_AsText;
/

