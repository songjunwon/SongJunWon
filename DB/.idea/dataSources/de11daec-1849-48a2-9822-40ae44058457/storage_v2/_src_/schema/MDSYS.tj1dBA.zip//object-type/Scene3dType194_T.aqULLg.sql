create TYPE         "Scene3dType194_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","srid" NUMBER(38),"Theme" "Theme196_COLL","ExternalTheme" "ExternalTheme199_COLL","DefaultStyle" "Style3dType200_T")NOT FINAL INSTANTIABLE
/

