create view DRV$ONLINE_PENDING as
select "ONL_CID","ONL_ROWID","ONL_INDEXPARTITION" from dr$online_pending
where onl_cid = SYS_CONTEXT('DR$APPCTX','IDXID')
with check option
/

