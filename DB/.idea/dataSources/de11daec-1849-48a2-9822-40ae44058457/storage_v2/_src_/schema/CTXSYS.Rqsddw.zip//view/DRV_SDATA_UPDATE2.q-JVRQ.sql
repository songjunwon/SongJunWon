create view DRV$SDATA_UPDATE2 as
select "SDU_IDX_ID","SDU_IXP_ID","SDU_SDATA_ID","SDU_DOCID","SDU_NV_TYPE","SDU_NV_NDATA","SDU_NV_DDATA","SDU_NV_CDATA","SDU_NV_RDATA" from dr$sdata_update
where sdu_idx_id = SYS_CONTEXT('DR$APPCTX','IDXID')
with check option
/

