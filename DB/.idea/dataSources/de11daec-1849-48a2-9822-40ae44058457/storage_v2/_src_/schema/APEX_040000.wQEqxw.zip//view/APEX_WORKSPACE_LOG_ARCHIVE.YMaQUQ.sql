create view APEX_WORKSPACE_LOG_ARCHIVE as
select
    w.short_name                           workspace,
    l.LOG_DAY,
    l.WORKSPACE_ID,
    l.APPLICATION_ID,
    l.PAGE_EVENTS,
    l.PAGE_VIEWS,
    l.PAGE_ACCEPTS,
    l.PARTIAL_PAGE_VIEWS,
    l.WEBSHEET_VIEWS,
    l.ROWS_FETCHED,
    l.IR_SEARCHES,
    l.DISTINCT_PAGES,
    l.DISTINCT_USERS,
    l.DISTINCT_SESSIONS,
    l.AVERAGE_RENDER_TIME,
    l.MEDIAN_RENDER_TIME,
    l.MAXIMUM_RENDER_TIME,
    l.TOTAL_RENDER_TIME,
    l.ERROR_COUNT,
    l.content_length
from WWV_FLOW_LOG_HISTORY l,
     wwv_flow_companies w,
     (select nvl(v('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
where (l.workspace_id in (select security_group_id from  wwv_flow_company_schemas where schema = user) or
       user in ('SYS','SYSTEM', 'APEX_040000')  or
       d.sgid = l.workspace_id) and
       l.workspace_id = w.PROVISIONING_COMPANY_ID and
      w.PROVISIONING_COMPANY_ID != 0
/

comment on table APEX_WORKSPACE_LOG_ARCHIVE is 'Page view activity is a daily summary of workspace acitivity that is retained until physically purged'
/

comment on column APEX_WORKSPACE_LOG_ARCHIVE.WORKSPACE is 'Name of Workspace that generated the page view log entry'
/

comment on column APEX_WORKSPACE_LOG_ARCHIVE.LOG_DAY is 'Day that all workspace statistics are summarized for'
/

comment on column APEX_WORKSPACE_LOG_ARCHIVE.WORKSPACE_ID is 'Identifies workspace'
/

comment on column APEX_WORKSPACE_LOG_ARCHIVE.PAGE_EVENTS is 'Total number of page events logged for a given day and workspace'
/

comment on column APEX_WORKSPACE_LOG_ARCHIVE.PAGE_VIEWS is 'Total page views for a given day and workspace'
/

comment on column APEX_WORKSPACE_LOG_ARCHIVE.PAGE_ACCEPTS is 'Total page accepts for a given day and workspace'
/

comment on column APEX_WORKSPACE_LOG_ARCHIVE.PARTIAL_PAGE_VIEWS is 'Total partial page views for a given day and workspace'
/

comment on column APEX_WORKSPACE_LOG_ARCHIVE.WEBSHEET_VIEWS is 'Total websheet application page views for a given day and workspace'
/

comment on column APEX_WORKSPACE_LOG_ARCHIVE.ROWS_FETCHED is 'Total rows fetched by apex reporting engines for a given day and workspace'
/

comment on column APEX_WORKSPACE_LOG_ARCHIVE.IR_SEARCHES is 'Total not null interactive report search values logged to the activity log'
/

comment on column APEX_WORKSPACE_LOG_ARCHIVE.DISTINCT_PAGES is 'Summarized information by day and workspace'
/

comment on column APEX_WORKSPACE_LOG_ARCHIVE.DISTINCT_USERS is 'Summarized information by day and workspace'
/

comment on column APEX_WORKSPACE_LOG_ARCHIVE.DISTINCT_SESSIONS is 'Summarized information by day and workspace'
/

comment on column APEX_WORKSPACE_LOG_ARCHIVE.AVERAGE_RENDER_TIME is 'Summarized information by day and workspace'
/

comment on column APEX_WORKSPACE_LOG_ARCHIVE.MEDIAN_RENDER_TIME is 'Summarized information by day and workspace'
/

comment on column APEX_WORKSPACE_LOG_ARCHIVE.MAXIMUM_RENDER_TIME is 'Summarized information by day and workspace'
/

comment on column APEX_WORKSPACE_LOG_ARCHIVE.TOTAL_RENDER_TIME is 'Summarized information by day and workspace'
/

comment on column APEX_WORKSPACE_LOG_ARCHIVE.ERROR_COUNT is 'Summarized information by day and workspace'
/

comment on column APEX_WORKSPACE_LOG_ARCHIVE.CONTENT_LENGTH is 'Summarized information by day and workspace'
/

