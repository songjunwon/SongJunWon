create view WWV_FLOW_FEEDBACK_TYPES as
select 1 id, wwv_flow_lang.system_message('GENERAL_COMMENT') the_name from dual union all
select 2 id, wwv_flow_lang.system_message('ENHANCEMENT_REQUEST') the_name from dual union all
select 3 id, wwv_flow_lang.system_message('BUG') the_name from dual
/

