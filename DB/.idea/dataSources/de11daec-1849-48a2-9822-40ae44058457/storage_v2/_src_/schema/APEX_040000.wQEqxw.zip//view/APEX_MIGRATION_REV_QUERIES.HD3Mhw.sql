create view APEX_MIGRATION_REV_QUERIES as
select
        a.project_id                                    project_id,
     --
        d.migration_name                                project_name,
     --
        d.migration_type                                migration_type,
     --
        a.dbid                                          dbid,
     --
        f.qryid                                         query_id,
     --
        f.orig_qry_name                                 orig_qry_name,
     --
        f.mig_view_name                                 mig_view_name,
     --
        f.orig_sql                                      orig_sql,
     --
        f.mig_sql                                       mig_sql,
     --
        f.owner                                         owner,
     --
        f.status                                        status,
     --
        f.created_on                                    created_on,
     --
        f.created_by                                    created_by,
     --
        a.last_updated_on                               last_updated_on,
     --
        a.last_updated_by                               last_updated_by,
     --
	s.schema                                        schema,
     --
	w.short_name                                    workspace,
     --
	w.provisioning_company_id                       workspace_id
     --
from
        wwv_mig_access a,
     --
        wwv_mig_rev_queries f,
     --
        wwv_flow_company_schemas s,
     --
        wwv_mig_projects d,
     --
        wwv_flow_companies w,
     --
        (select nvl(nv('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) g
     --
where
        (s.schema = user or user in ('SYS','SYSTEM','APEX_040000') or g.sgid = w.PROVISIONING_COMPANY_ID)
and     w.PROVISIONING_COMPANY_ID != 0
and     a.database_schema = s.schema
and     a.project_id = d.id
and     a.security_group_id = d.security_group_id
and     f.security_group_id = a.security_group_id
and     f.project_id = a.project_id
and     f.dbid = a.dbid
and     w.provisioning_company_id = a.security_group_id
and     w.provisioning_company_id = s.security_group_id
order by w.provisioning_company_id, f.project_id, f.qryid, f.dbid
/

comment on table APEX_MIGRATION_REV_QUERIES is 'Available MS Access report in the Application Express (Apex) Application Migrations Migration Projects'
/

comment on column APEX_MIGRATION_REV_QUERIES.PROJECT_ID is 'Primary key that identifies the migration project'
/

comment on column APEX_MIGRATION_REV_QUERIES.PROJECT_NAME is 'Identifies name of the migration project'
/

comment on column APEX_MIGRATION_REV_QUERIES.MIGRATION_TYPE is 'Identifies the type of Migration Project'
/

comment on column APEX_MIGRATION_REV_QUERIES.DBID is 'Identifies the unique number of the original MS Access database'
/

comment on column APEX_MIGRATION_REV_QUERIES.QUERY_ID is 'Identifies the unique number of the query in the original MS Access database'
/

comment on column APEX_MIGRATION_REV_QUERIES.ORIG_QRY_NAME is 'Identifies the name of the original MS Access query'
/

comment on column APEX_MIGRATION_REV_QUERIES.MIG_VIEW_NAME is 'Identifies the name of the migrated view associated with the MS Access query'
/

comment on column APEX_MIGRATION_REV_QUERIES.ORIG_SQL is 'Identifies the SQL syntax of the original query in the original MS Access database'
/

comment on column APEX_MIGRATION_REV_QUERIES.MIG_SQL is 'Identifies the SQL syntax of the migrated view'
/

comment on column APEX_MIGRATION_REV_QUERIES.OWNER is 'Identifies the owner of the MS Access database'
/

comment on column APEX_MIGRATION_REV_QUERIES.STATUS is 'Identifies the status of the migrated view: valid or invalid'
/

comment on column APEX_MIGRATION_REV_QUERIES.CREATED_ON is 'Date the QUERY was created in the original MS Access database'
/

comment on column APEX_MIGRATION_REV_QUERIES.CREATED_BY is 'Identidies the MS Access User Name who created the original MS Access query'
/

comment on column APEX_MIGRATION_REV_QUERIES.LAST_UPDATED_ON is 'Date of most recent changes to the Migration Project'
/

comment on column APEX_MIGRATION_REV_QUERIES.LAST_UPDATED_BY is 'Identifies the APEX User Name who last modified the MS Access database'
/

comment on column APEX_MIGRATION_REV_QUERIES.SCHEMA is 'Identifies the name of database schema associated with the Migration Project'
/

comment on column APEX_MIGRATION_REV_QUERIES.WORKSPACE is 'A work area mapped to one or more database schemas'
/

comment on column APEX_MIGRATION_REV_QUERIES.WORKSPACE_ID is 'Primary key that identifies the workspace'
/

