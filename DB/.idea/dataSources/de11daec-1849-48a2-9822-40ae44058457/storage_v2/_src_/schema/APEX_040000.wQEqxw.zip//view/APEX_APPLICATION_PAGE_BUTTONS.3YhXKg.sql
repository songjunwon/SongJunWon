create view APEX_APPLICATION_PAGE_BUTTONS as
select
     w.short_name                  workspace,
     p.flow_id                     application_id,
     f.name                        application_name,
     p.id                          page_id,
     p.name                        page_name,
     --
     b.BUTTON_SEQUENCE             button_sequence,
     (select plug_name
      from wwv_flow_page_plugs
      where id=b.BUTTON_PLUG_ID)   region,
     b.button_plug_id              region_id,
     b.BUTTON_NAME                 button_name,
     (select template_name
      from wwv_flow_button_templates
      where b.BUTTON_IMAGE =
         'template:'||to_char(id)
      and flow_id = f.id)          button_template,
     decode(substr(b.BUTTON_IMAGE,1,9),'template:',null,b.BUTTON_IMAGE) image_name,
     b.BUTTON_IMAGE_ALT            label,
     b.BUTTON_POSITION             display_position,
     b.BUTTON_ALIGNMENT            alignment,
     b.BUTTON_REDIRECT_URL         redirect_url,
     case nvl(b.button_execute_validations, 'Y')
       when 'Y' then 'Yes'
       when 'N' then 'No'
     end                           execute_validations,
     --
     nvl((select r from apex_standard_conditions where d = b.BUTTON_CONDITION_TYPE),b.BUTTON_CONDITION_TYPE)
                                   condition_type,
     b.BUTTON_CONDITION            condition_expression1,
     b.BUTTON_CONDITION2           condition_expression2,
     b.BUTTON_IMAGE_ATTRIBUTES     image_attributes,
     b.BUTTON_CATTRIBUTES          button_attributes,
     decode(
        b.DATABASE_ACTION,
        'DELETE','SQL DELETE action',
        'INSERT','SQL INSERT action',
        'UPDATE','SQL UPDATE action',
        b.DATABASE_ACTION)         database_action,
     --
     (select case when b.required_patch > 0 then PATCH_NAME else '{Not '||PATCH_NAME||'}' end PATCH_NAME
     from wwv_flow_patches
     where id= abs(b.REQUIRED_PATCH))   build_option,
     --
     decode(substr(b.SECURITY_SCHEME,1,1),'!','Not ')||
     nvl((select name
     from    wwv_flow_security_schemes
     where   to_char(id)= ltrim(b.SECURITY_SCHEME,'!')
     and     flow_id = f.id),
     b.SECURITY_SCHEME)            authorization_scheme,
     b.SECURITY_SCHEME             authorization_scheme_id,
     --
     b.LAST_UPDATED_BY             last_updated_by,
     b.LAST_UPDATED_ON             last_updated_on,
     b.BUTTON_COMMENT              component_comment,
     'Region Position'             button_position,
     b.id                          button_id,
     --
     b.BUTTON_NAME
     ||',s='||rpad(b.BUTTON_SEQUENCE,5,'00000')
     ||',r='||(select plug_name from wwv_flow_page_plugs where id=b.BUTTON_PLUG_ID)
     ||' t='||(select template_name from wwv_flow_button_templates where b.BUTTON_IMAGE = 'template:'||to_char(id) and flow_id = f.id)
     ||' label='||b.BUTTON_IMAGE_ALT
     ||' p='||b.BUTTON_POSITION
     ||' a='||b.BUTTON_ALIGNMENT
     ||' u='||substr(b.BUTTON_REDIRECT_URL,1,30)||length(b.BUTTON_REDIRECT_URL)
     ||' c='||b.BUTTON_CONDITION_TYPE
     ||substr(b.BUTTON_CONDITION,1,20)||length(b.BUTTON_CONDITION)||'.'
     ||substr(b.BUTTON_CONDITION2,1,20)||length(b.BUTTON_CONDITION2)
     ||' ii='||substr(b.BUTTON_IMAGE_ATTRIBUTES,1,20)||length(b.BUTTON_IMAGE_ATTRIBUTES)
     ||' ca='||substr(b.BUTTON_CATTRIBUTES,1,20)||length(b.BUTTON_CATTRIBUTES)
     ||' b='||decode(
        b.DATABASE_ACTION,
        'DELETE','SQLDELETE',
        'INSERT','SQLINSERT',
        'UPDATE','SQLUPDATE',
        b.DATABASE_ACTION)
     ||' b='||(select PATCH_NAME
     from wwv_flow_patches
     where id= abs(b.REQUIRED_PATCH))
     ||' s='||decode(substr(b.SECURITY_SCHEME,1,1),'!','Not ')||
     nvl((select name
     from    wwv_flow_security_schemes
     where   to_char(id)= ltrim(b.SECURITY_SCHEME,'!')
     and     flow_id = f.id),
     b.SECURITY_SCHEME)
     component_signature
from wwv_flow_step_buttons b,
     wwv_flow_steps p,
     wwv_flows f,
     wwv_flow_companies w,
     wwv_flow_company_schemas s,
     (select nvl(v('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
where (s.schema = user or user in ('SYS','SYSTEM', 'APEX_040000')  or d.sgid = s.security_group_id) and
      f.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.schema = f.owner and
      f.security_group_id = p.security_group_id and
      f.security_group_id = b.security_group_id and
      f.id = p.flow_id and
      f.id = b.flow_id and
      p.id = b.flow_step_id and
      (d.sgid != 0 or nvl(f.BUILD_STATUS,'x') != 'RUN_ONLY') and
      w.PROVISIONING_COMPANY_ID != 0
union all
select
    w.short_name                    workspace,
    p.flow_id                       application_id,
    f.name                          application_name,
    p.id                            page_id,
    p.name                          page_name,
    --
    i.ITEM_SEQUENCE                 button_sequence,
    (select plug_name
     from wwv_flow_page_plugs
     where id = i.ITEM_PLUG_ID)     region,
    i.item_plug_id                  region_id,
    i.name                          button_name,
    --
    null                            button_template,
    decode(substr(i.BUTTON_IMAGE,1,9),'template:',null,i.BUTTON_IMAGE) image_name,
    i.PROMPT                        label,
    null                            display_position,
    null                            alignment,
    null                            redirect_url,
    case nvl(i.button_execute_validations, 'Y')
      when 'Y' then 'Yes'
      when 'N' then 'No'
    end                             execute_validations,
    --
    nvl((select r from apex_standard_conditions where d = i.DISPLAY_WHEN_TYPE),i.DISPLAY_WHEN_TYPE)
                                    condition_type,
    i.DISPLAY_WHEN                  condition_expression1,
    i.DISPLAY_WHEN2                 condition_expression2,
    --
    null                            image_attributes,
    null                            button_attributes,
    null                            database_action,
    (select case when i.required_patch > 0 then PATCH_NAME else '{Not '||PATCH_NAME||'}' end PATCH_NAME
     from   wwv_flow_patches
     where  id =abs(i.REQUIRED_PATCH))   build_option,
    --
    decode(substr(i.SECURITY_SCHEME,1,1),'!','Not ')||
    nvl((select name
     from   wwv_flow_security_schemes
     where  to_char(id) = ltrim(i.SECURITY_SCHEME,'!')
     and    flow_id = f.id),
     i.SECURITY_SCHEME)             authorization_scheme,
    i.SECURITY_SCHEME               authorization_scheme_id,
    i.LAST_UPDATED_BY               last_updated_by,
    i.LAST_UPDATED_ON               last_updated_on,
    i.ITEM_COMMENT                  component_comment,
    'Among region items'            button_position,
    i.id                            button_id,
    --
    lpad(i.ITEM_SEQUENCE,5,'00000')
    ||' r='||(select plug_name
     from wwv_flow_page_plugs
     where id = i.ITEM_PLUG_ID)
    ||' n='||i.name
    ||' l='||substr(i.PROMPT,1,40)||length(i.PROMPT)
    ||' c='||i.DISPLAY_WHEN_TYPE
    ||'.'||substr(i.DISPLAY_WHEN,1,20)||length(i.DISPLAY_WHEN)
    ||'.'||substr(i.DISPLAY_WHEN2,1,20)||length(i.DISPLAY_WHEN2)
    ||' bo='||(select case when i.required_patch > 0 then PATCH_NAME else '{Not '||PATCH_NAME||'}' end PATCH_NAME
     from   wwv_flow_patches
     where  id =abs(i.REQUIRED_PATCH))
    ||' sec='||decode(substr(i.SECURITY_SCHEME,1,1),'!','Not ')||
    nvl((select name
     from   wwv_flow_security_schemes
     where  to_char(id) = ltrim(i.SECURITY_SCHEME,'!')
     and    flow_id = f.id),
     i.SECURITY_SCHEME)
    ||' ItemButton'
    component_signature
from wwv_flow_step_items i,
     wwv_flow_steps p,
     wwv_flows f,
     wwv_flow_companies w,
     wwv_flow_company_schemas s,
     (select nvl(v('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
where (s.schema = user or user in ('SYS','SYSTEM', 'APEX_040000')  or d.sgid = s.security_group_id) and
      f.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.schema = f.owner and
      f.security_group_id = p.security_group_id and
      f.id = p.flow_id and
      f.id = i.flow_id and
      p.id = i.flow_step_id and
      nvl(i.display_as,'x') = 'BUTTON' and
      (d.sgid != 0 or nvl(f.BUILD_STATUS,'x') != 'RUN_ONLY') and
      w.PROVISIONING_COMPANY_ID != 0
/

comment on table APEX_APPLICATION_PAGE_BUTTONS is 'Identifies buttons associated with a Page and Region'
/

comment on column APEX_APPLICATION_PAGE_BUTTONS.WORKSPACE is 'A work area mapped to one or more database schemas'
/

comment on column APEX_APPLICATION_PAGE_BUTTONS.APPLICATION_ID is 'Application Primary Key, Unique over all workspaces'
/

comment on column APEX_APPLICATION_PAGE_BUTTONS.APPLICATION_NAME is 'Identifies the application'
/

comment on column APEX_APPLICATION_PAGE_BUTTONS.PAGE_ID is 'Identifies the application'
/

comment on column APEX_APPLICATION_PAGE_BUTTONS.PAGE_NAME is 'Identifies a page within an application'
/

comment on column APEX_APPLICATION_PAGE_BUTTONS.BUTTON_SEQUENCE is 'Identifies the display sequence of the button within the region and display position'
/

comment on column APEX_APPLICATION_PAGE_BUTTONS.REGION is 'Identifies the Page Region in which this Button is displayed'
/

comment on column APEX_APPLICATION_PAGE_BUTTONS.REGION_ID is 'Identifies the Page Region foreign key to the apex_application_page_regions view'
/

comment on column APEX_APPLICATION_PAGE_BUTTONS.BUTTON_NAME is 'Identifies the name of the button, which when submitted becomes the REQUEST value'
/

comment on column APEX_APPLICATION_PAGE_BUTTONS.BUTTON_TEMPLATE is 'Identifies the template used to display this button'
/

comment on column APEX_APPLICATION_PAGE_BUTTONS.IMAGE_NAME is 'Name of image for non template based buttons'
/

comment on column APEX_APPLICATION_PAGE_BUTTONS.LABEL is 'Identifies the Button Label'
/

comment on column APEX_APPLICATION_PAGE_BUTTONS.DISPLAY_POSITION is 'Identifies the Display Position with the Region'
/

comment on column APEX_APPLICATION_PAGE_BUTTONS.ALIGNMENT is 'Identifies the button alignment used for selected display positions'
/

comment on column APEX_APPLICATION_PAGE_BUTTONS.REDIRECT_URL is 'Identifies an optional Page or URL to redirect to when this button is pressed.  If no Redirect URL is provided then the button will submit the page, a redirect will not submit the page.'
/

comment on column APEX_APPLICATION_PAGE_BUTTONS.EXECUTE_VALIDATIONS is 'Identifies if built-in validations and page validations should be executed when the page is submitted.'
/

comment on column APEX_APPLICATION_PAGE_BUTTONS.CONDITION_TYPE is 'Identifies the condition type used to conditionally display the Page Button'
/

comment on column APEX_APPLICATION_PAGE_BUTTONS.CONDITION_EXPRESSION1 is 'Specifies an expression based on the specific condition type selected.'
/

comment on column APEX_APPLICATION_PAGE_BUTTONS.CONDITION_EXPRESSION2 is 'Specifies an expression based on the specific condition type selected.'
/

comment on column APEX_APPLICATION_PAGE_BUTTONS.IMAGE_ATTRIBUTES is 'Identifies the HTML IMG tag attributes for the image used to display the button'
/

comment on column APEX_APPLICATION_PAGE_BUTTONS.BUTTON_ATTRIBUTES is 'Identifies the HTML INPUT tag attributes'
/

comment on column APEX_APPLICATION_PAGE_BUTTONS.DATABASE_ACTION is 'A button can be used to trigger table row processing (insert, update, and delete). This attribute determines the type of DML action to be performed.'
/

comment on column APEX_APPLICATION_PAGE_BUTTONS.BUILD_OPTION is 'Button will be displayed if the Build Option is enabled'
/

comment on column APEX_APPLICATION_PAGE_BUTTONS.AUTHORIZATION_SCHEME is 'An authorization scheme must evaluate to TRUE in order for this button to be displayed'
/

comment on column APEX_APPLICATION_PAGE_BUTTONS.AUTHORIZATION_SCHEME_ID is 'Foreign Key'
/

comment on column APEX_APPLICATION_PAGE_BUTTONS.LAST_UPDATED_BY is 'APEX developer who made last update'
/

comment on column APEX_APPLICATION_PAGE_BUTTONS.LAST_UPDATED_ON is 'Date of last update'
/

comment on column APEX_APPLICATION_PAGE_BUTTONS.COMPONENT_COMMENT is 'Developer comment'
/

comment on column APEX_APPLICATION_PAGE_BUTTONS.BUTTON_POSITION is 'Identifies where the button displays'
/

comment on column APEX_APPLICATION_PAGE_BUTTONS.BUTTON_ID is 'Primary key of this page button'
/

comment on column APEX_APPLICATION_PAGE_BUTTONS.COMPONENT_SIGNATURE is 'Identifies attributes defined at a given component level to facilitate application comparisons'
/

