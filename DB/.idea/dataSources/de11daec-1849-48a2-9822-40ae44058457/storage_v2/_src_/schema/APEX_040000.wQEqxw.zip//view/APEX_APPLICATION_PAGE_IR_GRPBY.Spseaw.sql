create view APEX_APPLICATION_PAGE_IR_GRPBY as
select
w.short_name          workspace,
f.id                  application_id,
f.name                application_name,
r.page_id             page_id,
r.worksheet_id        interactive_report_id,
g.websheet_id         websheet_id,
r.id                  report_id,
r.application_user    application_user,
r.name                report_name,
g.id                  group_by_id,
group_by_columns      ,
g.created_on          ,
g.created_by          ,
g.updated_on          last_updated_on,
g.updated_by          last_updated_by,
g.function_01         ,
g.function_column_01  ,
g.function_db_column_name_01 ,
g.function_label_01          ,
g.function_format_mask_01    ,
g.function_sum_01            ,
g.function_02                ,
g.function_column_02         ,
g.function_db_column_name_02 ,
g.function_label_02          ,
g.function_format_mask_02    ,
g.function_sum_02            ,
g.function_03                ,
g.function_column_03         ,
g.function_db_column_name_03 ,
g.function_label_03          ,
g.function_format_mask_03    ,
g.function_sum_03            ,
g.function_04                ,
g.function_column_04         ,
g.function_db_column_name_04 ,
g.function_label_04          ,
g.function_format_mask_04    ,
g.function_sum_04            ,
g.function_05                ,
g.function_column_05         ,
g.function_db_column_name_05 ,
g.function_label_05          ,
g.function_format_mask_05    ,
g.function_sum_05            ,
g.function_06                ,
g.function_column_06         ,
g.function_db_column_name_06 ,
g.function_label_06          ,
g.function_format_mask_06    ,
g.function_sum_06            ,
--
g.sort_column_01             ,
g.sort_direction_01          ,
g.sort_column_02             ,
g.sort_direction_02          ,
g.sort_column_03             ,
g.sort_direction_03          ,
g.sort_column_04             ,
g.sort_direction_04
--
from wwv_flow_worksheet_group_by g,
     wwv_flow_worksheet_rpts r,
     wwv_flow_worksheets ws,
     wwv_flows f,
     wwv_flow_companies w,
     wwv_flow_company_schemas s,
     (select nvl(nv('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
where (s.schema = user or user in ('SYS','SYSTEM', 'APEX_040000')  or d.sgid = s.security_group_id) and
      f.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.schema = f.owner and
      f.security_group_id = r.security_group_id and
      f.id = ws.flow_id and ws.id = r.worksheet_id and r.id = g.report_id and
      (d.sgid != 0 or nvl(f.BUILD_STATUS,'x') != 'RUN_ONLY') and
      w.PROVISIONING_COMPANY_ID != 0
/

comment on table APEX_APPLICATION_PAGE_IR_GRPBY is 'Identifies group by view defined in user-level report settings for an interactive report'
/

comment on column APEX_APPLICATION_PAGE_IR_GRPBY.WORKSPACE is 'A work area mapped to one or more database schemas'
/

comment on column APEX_APPLICATION_PAGE_IR_GRPBY.APPLICATION_ID is 'Application Primary Key, Unique over all workspaces'
/

comment on column APEX_APPLICATION_PAGE_IR_GRPBY.APPLICATION_NAME is 'Identifies the application'
/

comment on column APEX_APPLICATION_PAGE_IR_GRPBY.PAGE_ID is 'Identifies page number'
/

comment on column APEX_APPLICATION_PAGE_IR_GRPBY.INTERACTIVE_REPORT_ID is 'ID of the interactive report'
/

comment on column APEX_APPLICATION_PAGE_IR_GRPBY.WEBSHEET_ID is 'ID of the Websheet'
/

comment on column APEX_APPLICATION_PAGE_IR_GRPBY.REPORT_ID is 'ID of the report'
/

comment on column APEX_APPLICATION_PAGE_IR_GRPBY.APPLICATION_USER is 'The user these group by settings are used by'
/

comment on column APEX_APPLICATION_PAGE_IR_GRPBY.REPORT_NAME is 'The name of these report settings'
/

comment on column APEX_APPLICATION_PAGE_IR_GRPBY.GROUP_BY_ID is 'ID of this group by settings'
/

comment on column APEX_APPLICATION_PAGE_IR_GRPBY.GROUP_BY_COLUMNS is 'Columns to group by'
/

comment on column APEX_APPLICATION_PAGE_IR_GRPBY.CREATED_ON is 'Auditing; date the record was created.'
/

comment on column APEX_APPLICATION_PAGE_IR_GRPBY.CREATED_BY is 'Auditing; user that created the record.'
/

comment on column APEX_APPLICATION_PAGE_IR_GRPBY.LAST_UPDATED_ON is 'Auditing; date the record was last modified.'
/

comment on column APEX_APPLICATION_PAGE_IR_GRPBY.LAST_UPDATED_BY is 'Auditing; user that last modified the record.'
/

comment on column APEX_APPLICATION_PAGE_IR_GRPBY.FUNCTION_01 is 'Identifies the function to use in group by view'
/

comment on column APEX_APPLICATION_PAGE_IR_GRPBY.FUNCTION_COLUMN_01 is 'Identifies which column to use in the function'
/

comment on column APEX_APPLICATION_PAGE_IR_GRPBY.FUNCTION_DB_COLUMN_NAME_01 is 'Identifies the database column name the function used on'
/

comment on column APEX_APPLICATION_PAGE_IR_GRPBY.FUNCTION_LABEL_01 is 'Identifies the function column label'
/

comment on column APEX_APPLICATION_PAGE_IR_GRPBY.FUNCTION_FORMAT_MASK_01 is 'Identifies the format mask which can be used to format the function column'
/

comment on column APEX_APPLICATION_PAGE_IR_GRPBY.FUNCTION_SUM_01 is 'Determines whether to show the sum of the function column'
/

comment on column APEX_APPLICATION_PAGE_IR_GRPBY.FUNCTION_02 is 'Identifies the function to use in group by view'
/

comment on column APEX_APPLICATION_PAGE_IR_GRPBY.FUNCTION_COLUMN_02 is 'Identifies which column to use in the function'
/

comment on column APEX_APPLICATION_PAGE_IR_GRPBY.FUNCTION_DB_COLUMN_NAME_02 is 'Identifies the database column name the function used on'
/

comment on column APEX_APPLICATION_PAGE_IR_GRPBY.FUNCTION_LABEL_02 is 'Identifies the function column label'
/

comment on column APEX_APPLICATION_PAGE_IR_GRPBY.FUNCTION_FORMAT_MASK_02 is 'Identifies the format mask which can be used to format the function column'
/

comment on column APEX_APPLICATION_PAGE_IR_GRPBY.FUNCTION_SUM_02 is 'Determines whether to show the sum of the function column'
/

comment on column APEX_APPLICATION_PAGE_IR_GRPBY.FUNCTION_03 is 'Identifies the function to use in group by view'
/

comment on column APEX_APPLICATION_PAGE_IR_GRPBY.FUNCTION_COLUMN_03 is 'Identifies which column to use in the function'
/

comment on column APEX_APPLICATION_PAGE_IR_GRPBY.FUNCTION_DB_COLUMN_NAME_03 is 'Identifies the database column name the function used on'
/

comment on column APEX_APPLICATION_PAGE_IR_GRPBY.FUNCTION_LABEL_03 is 'Identifies the function column label'
/

comment on column APEX_APPLICATION_PAGE_IR_GRPBY.FUNCTION_FORMAT_MASK_03 is 'Identifies the format mask which can be used to format the function column'
/

comment on column APEX_APPLICATION_PAGE_IR_GRPBY.FUNCTION_SUM_03 is 'Determines whether to show the sum of the function column'
/

comment on column APEX_APPLICATION_PAGE_IR_GRPBY.FUNCTION_04 is 'Identifies the function to use in group by view'
/

comment on column APEX_APPLICATION_PAGE_IR_GRPBY.FUNCTION_COLUMN_04 is 'Identifies which column to use in the function'
/

comment on column APEX_APPLICATION_PAGE_IR_GRPBY.FUNCTION_DB_COLUMN_NAME_04 is 'Identifies the database column name the function used on'
/

comment on column APEX_APPLICATION_PAGE_IR_GRPBY.FUNCTION_LABEL_04 is 'Identifies the function column label'
/

comment on column APEX_APPLICATION_PAGE_IR_GRPBY.FUNCTION_FORMAT_MASK_04 is 'Identifies the format mask which can be used to format the function column'
/

comment on column APEX_APPLICATION_PAGE_IR_GRPBY.FUNCTION_SUM_04 is 'Determines whether to show the sum of the function column'
/

comment on column APEX_APPLICATION_PAGE_IR_GRPBY.FUNCTION_05 is 'Identifies the function to use in group by view'
/

comment on column APEX_APPLICATION_PAGE_IR_GRPBY.FUNCTION_COLUMN_05 is 'Identifies which column to use in the function'
/

comment on column APEX_APPLICATION_PAGE_IR_GRPBY.FUNCTION_DB_COLUMN_NAME_05 is 'Identifies the database column name the function used on'
/

comment on column APEX_APPLICATION_PAGE_IR_GRPBY.FUNCTION_LABEL_05 is 'Identifies the function column label'
/

comment on column APEX_APPLICATION_PAGE_IR_GRPBY.FUNCTION_FORMAT_MASK_05 is 'Identifies the format mask which can be used to format the function column'
/

comment on column APEX_APPLICATION_PAGE_IR_GRPBY.FUNCTION_SUM_05 is 'Determines whether to show the sum of the function column'
/

comment on column APEX_APPLICATION_PAGE_IR_GRPBY.FUNCTION_06 is 'Identifies the function to use in group by view'
/

comment on column APEX_APPLICATION_PAGE_IR_GRPBY.FUNCTION_COLUMN_06 is 'Identifies which column to use in the function'
/

comment on column APEX_APPLICATION_PAGE_IR_GRPBY.FUNCTION_DB_COLUMN_NAME_06 is 'Identifies the database column name the function used on'
/

comment on column APEX_APPLICATION_PAGE_IR_GRPBY.FUNCTION_LABEL_06 is 'Identifies the function column label'
/

comment on column APEX_APPLICATION_PAGE_IR_GRPBY.FUNCTION_FORMAT_MASK_06 is 'Identifies the format mask which can be used to format the function column'
/

comment on column APEX_APPLICATION_PAGE_IR_GRPBY.FUNCTION_SUM_06 is 'Determines whether to show the sum of the function column'
/

comment on column APEX_APPLICATION_PAGE_IR_GRPBY.SORT_COLUMN_01 is 'First column to sort by'
/

comment on column APEX_APPLICATION_PAGE_IR_GRPBY.SORT_DIRECTION_01 is 'Direction to use for first column sort'
/

comment on column APEX_APPLICATION_PAGE_IR_GRPBY.SORT_COLUMN_02 is 'Second column to sort by'
/

comment on column APEX_APPLICATION_PAGE_IR_GRPBY.SORT_DIRECTION_02 is 'Direction to use for second column sort'
/

comment on column APEX_APPLICATION_PAGE_IR_GRPBY.SORT_COLUMN_03 is 'Third column to sort by'
/

comment on column APEX_APPLICATION_PAGE_IR_GRPBY.SORT_DIRECTION_03 is 'Direction to use for third column sort'
/

comment on column APEX_APPLICATION_PAGE_IR_GRPBY.SORT_COLUMN_04 is 'Fourth column to sort by'
/

comment on column APEX_APPLICATION_PAGE_IR_GRPBY.SORT_DIRECTION_04 is 'Direction to use for fourth column sort'
/

