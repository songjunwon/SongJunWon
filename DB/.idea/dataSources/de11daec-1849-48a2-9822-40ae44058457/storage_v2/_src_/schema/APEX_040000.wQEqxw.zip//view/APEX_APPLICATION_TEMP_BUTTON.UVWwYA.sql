create view APEX_APPLICATION_TEMP_BUTTON as
select
    w.short_name                     workspace,
    f.ID                             application_id,
    f.NAME                           application_name,
    --
    t.THEME_ID                       theme_number,
    decode(t.THEME_CLASS_ID,
       '1','Button',
       '2','Button, Alternative 3',
       '4','Button, Alternative 1',
       '5','Button, Alternative 2',
       '6','Custom 1',
       '7','Custom 2',
       '8','Custom 3',
       '9','Custom 4',
       '10','Custom 5',
       '11','Custom 6',
       '12','Custom 7',
       '13','Custom 8',
       t.THEME_CLASS_ID)             theme_class,
    --
    t.TEMPLATE_NAME                  template_name,
    t.TEMPLATE                       ,
    --
    decode(t.REFERENCE_ID,
    null,'No','Yes')                 is_subscribed,
    (select flow_id||'. '||name
     from WWV_FLOW_button_TEMPLATES
     where id = t.REFERENCE_ID)      subscribed_from,
    --
    t.LAST_UPDATED_BY                last_updated_by,
    t.LAST_UPDATED_ON                last_updated_on,
    --
    decode(t.TRANSLATE_THIS_TEMPLATE,
      'Y','Yes','N','No','Yes')      translatable,
    t.TEMPLATE_COMMENT               component_comment,
    t.id                             button_template_id,
    --
    t.template_name
    ||' t='||t.THEME_ID
    ||' c='||t.THEME_CLASS_ID
    component_signature
from WWV_FLOW_button_TEMPLATES t,
     wwv_flows f,
     wwv_flow_companies w,
     wwv_flow_company_schemas s,
     (select nvl(nv('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
where (s.schema = user or user in ('SYS','SYSTEM', 'APEX_040000')  or d.sgid = s.security_group_id) and
      f.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.schema = f.owner and
      f.id = t.flow_id and
      (d.sgid != 0 or nvl(f.BUILD_STATUS,'x') != 'RUN_ONLY') and
      w.PROVISIONING_COMPANY_ID != 0
/

comment on table APEX_APPLICATION_TEMP_BUTTON is 'Identifies the HTML template markup used to display a Button'
/

comment on column APEX_APPLICATION_TEMP_BUTTON.WORKSPACE is 'A work area mapped to one or more database schemas'
/

comment on column APEX_APPLICATION_TEMP_BUTTON.APPLICATION_ID is 'Application Primary Key, Unique over all workspaces'
/

comment on column APEX_APPLICATION_TEMP_BUTTON.APPLICATION_NAME is 'Identifies the application'
/

comment on column APEX_APPLICATION_TEMP_BUTTON.THEME_NUMBER is 'Identifies the templates corresponding theme'
/

comment on column APEX_APPLICATION_TEMP_BUTTON.THEME_CLASS is 'Identifies a specific usage for this template'
/

comment on column APEX_APPLICATION_TEMP_BUTTON.TEMPLATE_NAME is 'Identifies the button template'
/

comment on column APEX_APPLICATION_TEMP_BUTTON.TEMPLATE is 'HTML Template'
/

comment on column APEX_APPLICATION_TEMP_BUTTON.IS_SUBSCRIBED is 'Identifies if this Button Template is subscribed from another Button Template'
/

comment on column APEX_APPLICATION_TEMP_BUTTON.SUBSCRIBED_FROM is 'Identifies the master component from which this component is subscribed'
/

comment on column APEX_APPLICATION_TEMP_BUTTON.LAST_UPDATED_BY is 'APEX developer who made last update'
/

comment on column APEX_APPLICATION_TEMP_BUTTON.LAST_UPDATED_ON is 'Date of last update'
/

comment on column APEX_APPLICATION_TEMP_BUTTON.TRANSLATABLE is 'Identifies if this component is to be identified as translatable (yes or no)'
/

comment on column APEX_APPLICATION_TEMP_BUTTON.COMPONENT_COMMENT is 'Developer comment'
/

comment on column APEX_APPLICATION_TEMP_BUTTON.BUTTON_TEMPLATE_ID is 'Primary Key of this Button Template'
/

comment on column APEX_APPLICATION_TEMP_BUTTON.COMPONENT_SIGNATURE is 'Identifies attributes defined at a given component level to facilitate application comparisons'
/

