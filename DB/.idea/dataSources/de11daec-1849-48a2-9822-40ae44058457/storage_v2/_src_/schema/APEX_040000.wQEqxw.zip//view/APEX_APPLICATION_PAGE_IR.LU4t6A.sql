create view APEX_APPLICATION_PAGE_IR as
select
w.short_name                 workspace,
f.id                         application_id,
f.name                       application_name,
ir.page_id                   page_id,
ir.id                        interactive_report_id,
ir.region_id                 region_id,
r.plug_name                  region_name,
--
(select count(*) from wwv_flow_worksheet_columns where worksheet_id = ir.id) number_of_columns,
(select count(*) from wwv_flow_worksheet_col_groups where worksheet_id = ir.id) number_of_column_groups,
(select count(*) from wwv_flow_worksheet_rpts where worksheet_id = ir.id and session_id is null and nvl(is_default,'N')='Y' and application_user='APXWS_ALTERNATIVE') number_of_alt_default_reportS,
(select count(*) from wwv_flow_worksheet_rpts where worksheet_id = ir.id and session_id is null and nvl(is_default,'N')='N' and status='PUBLIC') number_of_public_reports,
(select count(*) from wwv_flow_worksheet_rpts where worksheet_id = ir.id and session_id is null and nvl(is_default,'N')='N' and status='PRIVATE') number_of_private_reports,
ir.max_row_count             ,
ir.max_row_count_message     ,
ir.no_data_found_message     ,
ir.max_rows_per_page         ,
ir.search_button_label       ,
ir.page_items_to_submit      ,
ir.sort_asc_image            ,
ir.sort_asc_image_attr       ,
ir.sort_desc_image           ,
ir.sort_desc_image_attr      ,
ir.base_table_or_view        ,
ir.sql_query                 ,
--
ir.show_nulls_as             ,
decode(ir.pagination_type,
   'ROWS_X_TO_Y_OF_Z','Row Ranges X to Y of Z (no pagination)',
   'ROWS_X_TO_Y','Row Ranges X to Y (no pagination)',
   'SEARCH_ENGINE','Search Engine 1,2,3,4 (set based pagination)',
   'COMPUTED_BUT_NOT_DISPLAYED','Use Externally Created Pagination Buttons',
   'ROW_RANGES','Row Ranges 1-15 16-30 (with set pagination)',
   'ROW_RANGES_IN_SELECT_LIST','Row Ranges 1-15 16-30 in select list (with pagination)',
   'ROW_RANGES_WITH_LINKS','Row Ranges X to Y of Z (with pagination)',
   'NEXT_PREVIOUS_LINKS','Row Ranges X to Y (with next and previous links)',
   ir.pagination_type)       pagination_scheme,
decode(ir.pagination_display_position,
  'BOTTOM_LEFT','Bottom - Left',
  'BOTTOM_RIGHT','Bottom - Right',
  'TOP_LEFT','Top - Left',
  'TOP_RIGHT','Top - Right',
  'TOP_AND_BOTTOM_LEFT','Top and Bottom - Left',
  'TOP_AND_BOTTOM_RIGHT','Top and Bottom - Right',
  ir.pagination_display_position)     pagination_display_position,
(select template_name
 from wwv_flow_button_templates
 where ir.button_template = id
 and flow_id = f.id)          button_template,
--
decode(ir.show_finder_drop_down ,'Y','Yes','N','No',ir.show_finder_drop_down ) show_finder_drop_down ,
decode(ir.report_list_mode,'TABS', 'Yes','No') show_reports_select_list,
decode(ir.show_display_row_count,'Y','Yes','N','No',ir.show_display_row_count) show_display_row_count,
decode(ir.show_search_bar       ,'Y','Yes','N','No',ir.show_search_bar       ) show_search_bar       ,
decode(ir.show_search_textbox   ,'Y','Yes','N','No',ir.show_search_textbox   ) show_search_textbox   ,
decode(ir.show_actions_menu     ,'Y','Yes','N','No',ir.show_actions_menu     ) show_actions_menu     ,
ir.actions_menu_icon         ,
ir.finder_icon               ,
decode(ir.show_select_columns,'Y','Yes','N','No',ir.show_select_columns) show_select_columns,
decode(ir.show_rows_per_page ,'Y','Yes','N','No',ir.show_rows_per_page)  show_rows_per_page,
decode(ir.show_filter        ,'Y','Yes','N','No',ir.show_filter        ) show_filter        ,
decode(ir.show_sort          ,'Y','Yes','N','No',ir.show_sort          ) show_sort          ,
decode(ir.show_control_break ,'Y','Yes','N','No',ir.show_control_break ) show_control_break ,
decode(ir.show_highlight     ,'Y','Yes','N','No',ir.show_highlight     ) show_highlight     ,
decode(ir.show_computation   ,'Y','Yes','N','No',ir.show_computation   ) show_compute       ,
decode(ir.show_aggregate     ,'Y','Yes','N','No',ir.show_aggregate     ) show_aggregate     ,
decode(ir.show_chart         ,'Y','Yes','N','No',ir.show_chart         ) show_chart         ,
decode(ir.show_group_by      ,'Y','Yes','N','No',ir.show_group_by      ) show_group_by      ,
decode(ir.show_notify        ,'Y','Yes','N','No',ir.show_notify        ) show_notify        ,
decode(ir.show_flashback     ,'Y','Yes','N','No',ir.show_flashback     ) show_flashback     ,
decode(ir.allow_report_saving,'Y','Yes','N','No',ir.allow_report_saving) show_save          ,
decode(ir.allow_save_rpt_public,'Y','Yes','N','No',ir.allow_save_rpt_public) show_save_public,
decode(substr(ir.save_rpt_public_auth_scheme,1,1),'!','Not ')||
nvl((select name
 from   wwv_flow_security_schemes
 where  to_char(id) = ltrim(ir.save_rpt_public_auth_scheme,'!')
 and    flow_id = f.id),
 ir.save_rpt_public_auth_scheme)  save_public_auth_scheme,
ir.save_rpt_public_auth_scheme    save_public_auth_scheme_id,
decode(ir.show_reset         ,'Y','Yes','N','No',ir.show_reset         ) show_reset         ,
decode(ir.show_download      ,'Y','Yes','N','No',ir.show_download      ) show_download      ,
decode(ir.show_help          ,'Y','Yes','N','No',ir.show_help          ) show_help          ,
ir.download_formats          ,
ir.download_filename         filename,
ir.csv_output_separator      separator,
ir.csv_output_enclosed_by    enclosed_by,
--
decode(ir.show_detail_link,
       'Y', 'Single Row View',
       'C', 'Custom Link target',
       'N', 'No Link Column') detail_link_type,
ir.detail_link                detail_link_target,
ir.detail_link_text           detail_link_text,
ir.detail_link_attr           detail_link_attributes,
ir.detail_link_checksum_type  detail_link_checksum_type,
nvl((select r from apex_standard_conditions where d = ir.detail_link_condition_type),ir.detail_link_condition_type)
                                     detail_link_condition_type,
ir.detail_link_cond           detail_link_cond_expression,
ir.detail_link_cond2          detail_link_cond_expression2,
decode(substr(ir.detail_link_auth_SCHEME,1,1),'!','Not ')||
nvl((select name
 from   wwv_flow_security_schemes
 where  to_char(id) = ltrim(ir.detail_link_auth_scheme,'!')
 and    flow_id = f.id),
 ir.detail_link_auth_scheme)  detail_link_auth_scheme,
ir.detail_link_auth_scheme    detail_link_auth_scheme_id,
--
ir.alias                      alias,
ir.report_id_item             ,
ir.max_query_cost             ,
--
    decode(icon_view_enabled_yn,'Y','Yes','N','No','No') icon_view_enabled_yn,
    icon_view_link_column     ,
    icon_view_img_src_column  ,
    icon_view_label_column    ,
    icon_view_img_attr_text   ,
    icon_view_alt_text        ,
    icon_view_title_text      ,
    icon_view_columns_per_row ,
    --
    decode(detail_view_enabled_yn,'Y','Yes','N','No','No') detail_view_enabled_yn,
    detail_view_before_rows,
    detail_view_for_each_row,
    detail_view_after_rows,
--
ir.created_on,
ir.created_by,
ir.updated_on,
ir.updated_by,
--
'Interactive Report'||
' rc='||ir.max_row_count||
' '||length(ir.max_row_count_message)||
length(ir.no_data_found_message)||
ir.max_rows_per_page||
substr(ir.search_button_label,1,30)||
length(page_items_to_submit)||
length(ir.sort_asc_image)||
length(ir.sort_asc_image_attr)||
length(ir.sort_desc_image)||
length(ir.sort_desc_image_attr)||
substr(ir.show_nulls_as,1,30)||
' p='||ir.pagination_type||
' '||ir.pagination_display_position||
' '||substr(ir.actions_menu_icon,1,30)||
' '||substr(ir.finder_icon,1,30)||
' opt='||ir.show_finder_drop_down||
ir.show_display_row_count||
ir.show_search_bar||
ir.show_search_textbox||
ir.show_actions_menu||
ir.show_select_columns||
ir.show_rows_per_page||
ir.show_filter||
ir.show_sort||
ir.show_control_break||
ir.show_highlight||
ir.show_computation||
ir.show_aggregate||
ir.show_chart||
ir.show_group_by||
ir.show_notify||
ir.show_flashback||
ir.allow_report_saving||
ir.allow_save_rpt_public||
ir.save_rpt_public_auth_scheme||
ir.show_reset||
ir.show_download||
ir.show_help||
' rpts='||ir.report_list_mode||
' dl='||substr(ir.download_formats,1,40)||
' fn='||substr(ir.download_filename,1,30)||
ir.csv_output_separator||
ir.csv_output_enclosed_by||
ir.show_detail_link||
' l='||substr(ir.detail_link,1,30)||
' lt='||substr(ir.detail_link_text,1,30)||
substr(ir.detail_link_attr,1,30)||
ir.detail_link_checksum_type||
' lc='||ir.detail_link_condition_type||
length(ir.detail_link_cond)||
length(ir.detail_link_cond2)||
ir.detail_link_auth_SCHEME||
' a='||substr(ir.alias,1,30)||
ir.report_id_item||
ir.max_query_cost
component_signature
--
from wwv_flow_worksheets ir,
     wwv_flow_page_plugs r,
     wwv_flows f,
     wwv_flow_companies w,
     wwv_flow_company_schemas s,
     (select nvl(nv('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
where (s.schema = user or user in ('SYS','SYSTEM', 'APEX_040000')  or d.sgid = s.security_group_id) and
      f.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.schema = f.owner and
      f.security_group_id = ir.security_group_id and
      r.id (+) = ir.region_id and
      f.id = ir.flow_id and
      (d.sgid != 0 or nvl(f.BUILD_STATUS,'x') != 'RUN_ONLY') and
      w.PROVISIONING_COMPANY_ID != 0
/

comment on table APEX_APPLICATION_PAGE_IR is 'Identifies attributes of an interactive report'
/

comment on column APEX_APPLICATION_PAGE_IR.WORKSPACE is 'A work area mapped to one or more database schemas'
/

comment on column APEX_APPLICATION_PAGE_IR.APPLICATION_ID is 'Application Primary Key, Unique over all workspaces'
/

comment on column APEX_APPLICATION_PAGE_IR.APPLICATION_NAME is 'Identifies the application'
/

comment on column APEX_APPLICATION_PAGE_IR.PAGE_ID is 'Identifies page number'
/

comment on column APEX_APPLICATION_PAGE_IR.INTERACTIVE_REPORT_ID is 'ID of the interactive report'
/

comment on column APEX_APPLICATION_PAGE_IR.REGION_ID is 'ID of the interactive report region'
/

comment on column APEX_APPLICATION_PAGE_IR.REGION_NAME is 'Name of the interactive report region'
/

comment on column APEX_APPLICATION_PAGE_IR.NUMBER_OF_COLUMNS is 'Total number of columns returned by the query for this report region'
/

comment on column APEX_APPLICATION_PAGE_IR.NUMBER_OF_COLUMN_GROUPS is 'Number of defined column groups for this report region'
/

comment on column APEX_APPLICATION_PAGE_IR.NUMBER_OF_ALT_DEFAULT_REPORTS is 'Number of developer-defined alternative default reports for this report region'
/

comment on column APEX_APPLICATION_PAGE_IR.NUMBER_OF_PUBLIC_REPORTS is 'Number of user-defined public shared reports for this report region'
/

comment on column APEX_APPLICATION_PAGE_IR.NUMBER_OF_PRIVATE_REPORTS is 'Number of user-defined private reports for this report region'
/

comment on column APEX_APPLICATION_PAGE_IR.MAX_ROW_COUNT is 'Maximum number of rows to query before sorting'
/

comment on column APEX_APPLICATION_PAGE_IR.MAX_ROW_COUNT_MESSAGE is 'Message to display if the maximum number of rows is exceeded'
/

comment on column APEX_APPLICATION_PAGE_IR.NO_DATA_FOUND_MESSAGE is 'Message to display when no rows are returned by the report query'
/

comment on column APEX_APPLICATION_PAGE_IR.MAX_ROWS_PER_PAGE is 'Maximum number of rows to display on a single HTML page.  The Rows select list will not display any values higher than this amount.'
/

comment on column APEX_APPLICATION_PAGE_IR.SEARCH_BUTTON_LABEL is 'Text to use for the search button label'
/

comment on column APEX_APPLICATION_PAGE_IR.PAGE_ITEMS_TO_SUBMIT is 'List of page items values which are submitted when the search button is clicked'
/

comment on column APEX_APPLICATION_PAGE_IR.SORT_ASC_IMAGE is 'Defines the image shown in report headings to sort column values in ascending order.'
/

comment on column APEX_APPLICATION_PAGE_IR.SORT_ASC_IMAGE_ATTR is 'Image attributes for sort images used to define attributes such width and height of image.'
/

comment on column APEX_APPLICATION_PAGE_IR.SORT_DESC_IMAGE is 'Defines the image shown in report headings to sort column values in descending order.'
/

comment on column APEX_APPLICATION_PAGE_IR.SORT_DESC_IMAGE_ATTR is 'Image attributes for sort images used to define attributes such width and height of image.'
/

comment on column APEX_APPLICATION_PAGE_IR.BASE_TABLE_OR_VIEW is 'Table or View used as the base for this interactive report region.'
/

comment on column APEX_APPLICATION_PAGE_IR.SQL_QUERY is 'Query used as the base for this interactive report region.  The original query will be preserved as a subquery in the actual SQL used for the report'
/

comment on column APEX_APPLICATION_PAGE_IR.SHOW_NULLS_AS is 'Identifies the text to display for null columns. The default value is "-".'
/

comment on column APEX_APPLICATION_PAGE_IR.PAGINATION_SCHEME is 'Identifies the pagination style to use for this report'
/

comment on column APEX_APPLICATION_PAGE_IR.PAGINATION_DISPLAY_POSITION is 'Identifies the position of pagination links relative to this report'
/

comment on column APEX_APPLICATION_PAGE_IR.BUTTON_TEMPLATE is 'Optionally identifies the button template to use in place of the generic buttons'
/

comment on column APEX_APPLICATION_PAGE_IR.SHOW_FINDER_DROP_DOWN is 'Determines whether to display the drop down to the left of the search field'
/

comment on column APEX_APPLICATION_PAGE_IR.SHOW_REPORTS_SELECT_LIST is 'Determines whether saved reports are displayed as select list in the Search Bar.'
/

comment on column APEX_APPLICATION_PAGE_IR.SHOW_DISPLAY_ROW_COUNT is 'Determines whether to display the row count selector in the Search Bar'
/

comment on column APEX_APPLICATION_PAGE_IR.SHOW_SEARCH_BAR is 'Determines whether to display the Search Bar for the interactive report'
/

comment on column APEX_APPLICATION_PAGE_IR.SHOW_SEARCH_TEXTBOX is 'Determines whether to allow searching from the Search Bar'
/

comment on column APEX_APPLICATION_PAGE_IR.SHOW_ACTIONS_MENU is 'Determines whether to display the Actions Menu and Actions Menu icon in the Search Bar'
/

comment on column APEX_APPLICATION_PAGE_IR.ACTIONS_MENU_ICON is 'Identifies the icon used for the Actions Menu.  The default icon is a green gear.'
/

comment on column APEX_APPLICATION_PAGE_IR.FINDER_ICON is 'Identifies the icon displayed on the left of the Search Bar.  The default icon is a magnifying glass.'
/

comment on column APEX_APPLICATION_PAGE_IR.SHOW_SELECT_COLUMNS is 'Determines whether to show the Select Columns option in the Actions Menu'
/

comment on column APEX_APPLICATION_PAGE_IR.SHOW_ROWS_PER_PAGE is 'Determines whether to show the Rows Per Page option in the Actions Menu'
/

comment on column APEX_APPLICATION_PAGE_IR.SHOW_FILTER is 'Determines whether to show the Filter option in the Actions Menu'
/

comment on column APEX_APPLICATION_PAGE_IR.SHOW_SORT is 'Determines whether to show the Sort option in the Actions Menu'
/

comment on column APEX_APPLICATION_PAGE_IR.SHOW_CONTROL_BREAK is 'Determines whether to show the Control option in the Actions Menu'
/

comment on column APEX_APPLICATION_PAGE_IR.SHOW_HIGHLIGHT is 'Determines whether to show the Highlight option in the Actions Menu'
/

comment on column APEX_APPLICATION_PAGE_IR.SHOW_COMPUTE is 'Determines whether to show the Compute option in the Actions Menu'
/

comment on column APEX_APPLICATION_PAGE_IR.SHOW_AGGREGATE is 'Determines whether to show the Aggregate option in the Actions Menu'
/

comment on column APEX_APPLICATION_PAGE_IR.SHOW_CHART is 'Determines whether to show the Chart option in the Actions Menu'
/

comment on column APEX_APPLICATION_PAGE_IR.SHOW_GROUP_BY is 'Determines whether to show the Group By option in the Actions Menu'
/

comment on column APEX_APPLICATION_PAGE_IR.SHOW_NOTIFY is 'Determines whether to show the Notify option in the Actions Menu'
/

comment on column APEX_APPLICATION_PAGE_IR.SHOW_FLASHBACK is 'Determines whether to show the Flashback option in the Actions Menu'
/

comment on column APEX_APPLICATION_PAGE_IR.SHOW_SAVE is 'Determines whether to show the Save Report option in the Actions Menu'
/

comment on column APEX_APPLICATION_PAGE_IR.SHOW_SAVE_PUBLIC is 'Determines whether to show the Public option in the Save Report dialog'
/

comment on column APEX_APPLICATION_PAGE_IR.SAVE_PUBLIC_AUTH_SCHEME is 'This authorization scheme must evaluate to TRUE in order for Public option to display in Save Report dialog'
/

comment on column APEX_APPLICATION_PAGE_IR.SAVE_PUBLIC_AUTH_SCHEME_ID is 'Foreign Key'
/

comment on column APEX_APPLICATION_PAGE_IR.SHOW_RESET is 'Determines whether to show the Reset option in the Actions Menu'
/

comment on column APEX_APPLICATION_PAGE_IR.SHOW_DOWNLOAD is 'Determines whether to show the Download option in the Actions Menu'
/

comment on column APEX_APPLICATION_PAGE_IR.SHOW_HELP is 'Determines whether to show the Help option in the Actions Menu'
/

comment on column APEX_APPLICATION_PAGE_IR.DOWNLOAD_FORMATS is 'Identifies the download formats supported for this interactive report'
/

comment on column APEX_APPLICATION_PAGE_IR.FILENAME is 'Identifies the filename prefix used when this report data is downloaded'
/

comment on column APEX_APPLICATION_PAGE_IR.SEPARATOR is 'Identifies a column separator. If no value is entered, a comma or semicolon is used depending on your current NLS settings.'
/

comment on column APEX_APPLICATION_PAGE_IR.ENCLOSED_BY is 'Identifies a delimiter character. This character is used to delineate the starting and ending boundary of a data value. Default delimiter is double quotes.'
/

comment on column APEX_APPLICATION_PAGE_IR.DETAIL_LINK_TYPE is 'Identifies the type of link to display in the Link Column on the left of the interactive report'
/

comment on column APEX_APPLICATION_PAGE_IR.DETAIL_LINK_TARGET is 'Target of the Link Column, if a custom target is defined'
/

comment on column APEX_APPLICATION_PAGE_IR.DETAIL_LINK_TEXT is 'Text or HTML to display in the Link Column'
/

comment on column APEX_APPLICATION_PAGE_IR.DETAIL_LINK_ATTRIBUTES is 'Link attributes for the Link Column.  Displayed within the HTML "A" tag'
/

comment on column APEX_APPLICATION_PAGE_IR.DETAIL_LINK_CHECKSUM_TYPE is 'An appropriate checksum when linking to protected pages'
/

comment on column APEX_APPLICATION_PAGE_IR.DETAIL_LINK_CONDITION_TYPE is 'For conditionally displayed Link Column; identifies the condition type to evaluate'
/

comment on column APEX_APPLICATION_PAGE_IR.DETAIL_LINK_COND_EXPRESSION is 'Specifies an expression based on the specific condition type selected.'
/

comment on column APEX_APPLICATION_PAGE_IR.DETAIL_LINK_COND_EXPRESSION2 is 'Specifies an expression based on the specific condition type selected.'
/

comment on column APEX_APPLICATION_PAGE_IR.DETAIL_LINK_AUTH_SCHEME is 'This authorization scheme must evaluate to TRUE in order for this page to be displayed'
/

comment on column APEX_APPLICATION_PAGE_IR.DETAIL_LINK_AUTH_SCHEME_ID is 'Foreign Key'
/

comment on column APEX_APPLICATION_PAGE_IR.ALIAS is 'Alias for this interactive report, may be used for API references'
/

comment on column APEX_APPLICATION_PAGE_IR.REPORT_ID_ITEM is 'Item which holds the saved report ID to display'
/

comment on column APEX_APPLICATION_PAGE_IR.MAX_QUERY_COST is 'Prevent execution of queries that are estimated to take longer than specified amount of time.'
/

comment on column APEX_APPLICATION_PAGE_IR.ICON_VIEW_ENABLED_YN is 'Identifies that an icon view is enabled and selectable from the interactive report'
/

comment on column APEX_APPLICATION_PAGE_IR.ICON_VIEW_LINK_COLUMN is 'Identifies the report column that returns the link target of the icon'
/

comment on column APEX_APPLICATION_PAGE_IR.ICON_VIEW_IMG_SRC_COLUMN is 'Identifies the report column that returns the image source'
/

comment on column APEX_APPLICATION_PAGE_IR.ICON_VIEW_LABEL_COLUMN is 'Identifies the report column that returns the image label'
/

comment on column APEX_APPLICATION_PAGE_IR.ICON_VIEW_IMG_ATTR_TEXT is 'Identifies the image attributes used for the HTML IMG tag.'
/

comment on column APEX_APPLICATION_PAGE_IR.ICON_VIEW_ALT_TEXT is 'Identifies the HTML ALT text for the image.'
/

comment on column APEX_APPLICATION_PAGE_IR.ICON_VIEW_TITLE_TEXT is 'Identifies the HTML TITLE tag for the image.'
/

comment on column APEX_APPLICATION_PAGE_IR.ICON_VIEW_COLUMNS_PER_ROW is 'Identifies the number of icons to be displayed per row'
/

comment on column APEX_APPLICATION_PAGE_IR.DETAIL_VIEW_ENABLED_YN is 'Identifies that detail view is enabled and selectable from the interactive report'
/

comment on column APEX_APPLICATION_PAGE_IR.DETAIL_VIEW_BEFORE_ROWS is 'Identifies the HTML to be displayed before report rows'
/

comment on column APEX_APPLICATION_PAGE_IR.DETAIL_VIEW_FOR_EACH_ROW is 'Identifies the HTML to be displayed for each report row'
/

comment on column APEX_APPLICATION_PAGE_IR.DETAIL_VIEW_AFTER_ROWS is 'Identifies the HTML to be displayed after report rows'
/

comment on column APEX_APPLICATION_PAGE_IR.CREATED_ON is 'Auditing; date the record was created.'
/

comment on column APEX_APPLICATION_PAGE_IR.CREATED_BY is 'Auditing; user that created the record.'
/

comment on column APEX_APPLICATION_PAGE_IR.UPDATED_ON is 'Auditing; date the record was last modified.'
/

comment on column APEX_APPLICATION_PAGE_IR.UPDATED_BY is 'Auditing; user that last modified the record.'
/

comment on column APEX_APPLICATION_PAGE_IR.COMPONENT_SIGNATURE is 'Identifies attributes defined at a given component level to facilitate application comparisons'
/

