create view APEX_TEAM_FEEDBACK_FOLLOWUP as
select
    w.PROVISIONING_COMPANY_ID   workspace_id,
    w.short_name                workspace_name,
    --
    f.ID                        followup_id,
    f.feedback_id               feedback_id,
    --
    f.follow_up,
    f.email,
    --
    f.CREATED_BY,
    f.CREATED_ON,
    f.UPDATED_BY,
    f.UPDATED_ON
from
    wwv_flow_feedback_followup f,
    wwv_flow_feedback fe,
    wwv_flow_companies w
where
    f.feedback_id = fe.id and
    fe.security_group_id = w.PROVISIONING_COMPANY_ID and
    w.PROVISIONING_COMPANY_ID in (
       select security_group_id
       from   wwv_flow_company_schemas s,
              (select nvl(v('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
       where  (s.schema = user or user in ('SYS','SYSTEM', 'APEX_040000') or d.sgid = s.security_group_id) ) and
    (user in ('SYS', 'SYSTEM', 'APEX_040000') or w.PROVISIONING_COMPANY_ID != 10)
/

comment on table APEX_TEAM_FEEDBACK_FOLLOWUP is 'Identifies user feedback followup.'
/

comment on column APEX_TEAM_FEEDBACK_FOLLOWUP.WORKSPACE_ID is 'Primary key that identifies the workspace.'
/

comment on column APEX_TEAM_FEEDBACK_FOLLOWUP.WORKSPACE_NAME is 'Name of the current workspace.'
/

comment on column APEX_TEAM_FEEDBACK_FOLLOWUP.FOLLOWUP_ID is 'Primary key of the feedback followup entry.'
/

comment on column APEX_TEAM_FEEDBACK_FOLLOWUP.FEEDBACK_ID is 'Associated feedback entry.'
/

comment on column APEX_TEAM_FEEDBACK_FOLLOWUP.FOLLOW_UP is 'Followup comments provided by user.'
/

comment on column APEX_TEAM_FEEDBACK_FOLLOWUP.EMAIL is 'Email address provided with followup.'
/

comment on column APEX_TEAM_FEEDBACK_FOLLOWUP.CREATED_BY is 'User that created this feedback followup.'
/

comment on column APEX_TEAM_FEEDBACK_FOLLOWUP.CREATED_ON is 'Date this feedback followup was created.'
/

comment on column APEX_TEAM_FEEDBACK_FOLLOWUP.UPDATED_BY is 'Developer who made last update.'
/

comment on column APEX_TEAM_FEEDBACK_FOLLOWUP.UPDATED_ON is 'Date of last update.'
/

