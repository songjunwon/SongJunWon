create view APEX_APPL_PLUGIN_ATTRIBUTES as
select a.id                 as plugin_attribute_id,
       f.workspace,
       f.application_id,
       f.application_name,
       a.plugin_id,
       p.name               as plugin_name,
       case a.attribute_scope
         when 'APPLICATION' then 'Application'
         when 'COMPONENT'   then 'Component'
         else a.attribute_scope
       end                  as attribute_scope,
       a.attribute_sequence,
       a.display_sequence,
       a.prompt,
       case a.attribute_type
         when 'CHECKBOX'         then 'Checkbox'
         when 'SELECT LIST'      then 'Select List'
         when 'TEXT'             then 'Text'
         when 'TEXTAREA'         then 'Textarea'
         when 'NUMBER'           then 'Number'
         when 'INTEGER'          then 'Integer'
         when 'PAGE ITEM'        then 'Page Item'
         when 'PAGE ITEMS'       then 'Page Items'
         when 'PAGE NUMBER'      then 'Page Number'
         when 'SQL'              then 'SQL Query'
         when 'PLSQL'            then 'PL/SQL Code'
         when 'PLSQL EXPRESSION' then 'PL/SQL Expression'
         else a.attribute_type
       end                  as attribute_type,
       case a.is_required
         when 'Y' then 'Yes'
         else          'No'
       end                  as is_required,
       a.default_value,
       a.display_length,
       a.max_length,
       a.sql_min_column_count,
       a.sql_max_column_count,
       a.is_translatable,
       a.depending_on_attribute_id,
       case a.depending_on_condition_type
         when 'EQUALS'       then 'equal to'
         when 'NOT_EQUALS'   then 'not equal to'
         when 'NULL'         then 'is null'
         when 'NOT_NULL'     then 'is not null'
         when 'IN_LIST'      then 'in list'
         when 'NOT_IN_LIST'  then 'not in list'
         else a.depending_on_condition_type
       end depending_on_condition_type,
       a.depending_on_expression,
       a.help_text,
       a.attribute_comment  as component_comment,
       a.created_by,
       a.created_on,
       a.last_updated_by,
       a.last_updated_on
  from wwv_flow_authorized f,
       wwv_flow_plugins p,
       wwv_flow_plugin_attributes a
 where p.flow_id   = f.application_id
   and a.plugin_id = p.id
/

comment on table APEX_APPL_PLUGIN_ATTRIBUTES is 'Stores the meta data for the dynamic attributes of a plug-in.'
/

comment on column APEX_APPL_PLUGIN_ATTRIBUTES.PLUGIN_ATTRIBUTE_ID is 'Identifies the primary key of this component'
/

comment on column APEX_APPL_PLUGIN_ATTRIBUTES.WORKSPACE is 'A work area mapped to one or more database schemas'
/

comment on column APEX_APPL_PLUGIN_ATTRIBUTES.APPLICATION_ID is 'Application Primary Key, Unique over all workspaces'
/

comment on column APEX_APPL_PLUGIN_ATTRIBUTES.APPLICATION_NAME is 'Identifies the application'
/

comment on column APEX_APPL_PLUGIN_ATTRIBUTES.PLUGIN_ID is 'Id of the plug-in this plugin attribute is part of'
/

comment on column APEX_APPL_PLUGIN_ATTRIBUTES.PLUGIN_NAME is 'Name of the plug-in this plugin attribute is part of'
/

comment on column APEX_APPL_PLUGIN_ATTRIBUTES.ATTRIBUTE_SCOPE is 'Is the attribute set for an application or a component.'
/

comment on column APEX_APPL_PLUGIN_ATTRIBUTES.ATTRIBUTE_SEQUENCE is 'Sequence which correlates with the attribute_xx columns for example in apex_application_page_items.'
/

comment on column APEX_APPL_PLUGIN_ATTRIBUTES.DISPLAY_SEQUENCE is 'Sequence in which the attributes are displayed in the Builder.'
/

comment on column APEX_APPL_PLUGIN_ATTRIBUTES.PROMPT is 'Prompt which is displayed for that attribute in the Builder.'
/

comment on column APEX_APPL_PLUGIN_ATTRIBUTES.ATTRIBUTE_TYPE is 'Type of control which is used to render the attribute field in the Builder.'
/

comment on column APEX_APPL_PLUGIN_ATTRIBUTES.IS_REQUIRED is 'Should the Builder enforce this attribute to be filled out?'
/

comment on column APEX_APPL_PLUGIN_ATTRIBUTES.DEFAULT_VALUE is 'Default value which is used in the Builder when the item type is selected.'
/

comment on column APEX_APPL_PLUGIN_ATTRIBUTES.DISPLAY_LENGTH is 'Display length of the attribute used when displayed in the Builder.'
/

comment on column APEX_APPL_PLUGIN_ATTRIBUTES.MAX_LENGTH is 'Maximum length of the attribute used when displayed in the Builder.'
/

comment on column APEX_APPL_PLUGIN_ATTRIBUTES.SQL_MIN_COLUMN_COUNT is 'Minimum number of columns the SQL query of the attribute has to have.'
/

comment on column APEX_APPL_PLUGIN_ATTRIBUTES.SQL_MAX_COLUMN_COUNT is 'Maximum number of columns the SQL query of the attribute can have.'
/

comment on column APEX_APPL_PLUGIN_ATTRIBUTES.IS_TRANSLATABLE is 'Is the attribute value exported into the XLIFF file for translation.'
/

comment on column APEX_APPL_PLUGIN_ATTRIBUTES.DEPENDING_ON_ATTRIBUTE_ID is 'Attribute which defines if the current attribute is displayed or not.'
/

comment on column APEX_APPL_PLUGIN_ATTRIBUTES.DEPENDING_ON_CONDITION_TYPE is 'Identifies the type of condition used to define when the attribute gets displayed.'
/

comment on column APEX_APPL_PLUGIN_ATTRIBUTES.DEPENDING_ON_EXPRESSION is 'Identifies the condition expression used to define when the attribute gets displayed.'
/

comment on column APEX_APPL_PLUGIN_ATTRIBUTES.HELP_TEXT is 'Help text displayed in APEX Builder for this attribute.'
/

comment on column APEX_APPL_PLUGIN_ATTRIBUTES.COMPONENT_COMMENT is 'Developer Comment'
/

comment on column APEX_APPL_PLUGIN_ATTRIBUTES.CREATED_BY is 'APEX developer who created the plugin attribute'
/

comment on column APEX_APPL_PLUGIN_ATTRIBUTES.CREATED_ON is 'Date of creation'
/

comment on column APEX_APPL_PLUGIN_ATTRIBUTES.LAST_UPDATED_BY is 'APEX developer who made last update'
/

comment on column APEX_APPL_PLUGIN_ATTRIBUTES.LAST_UPDATED_ON is 'Date of last update'
/

