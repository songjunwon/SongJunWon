create view APEX_WS_APPLICATIONS as
select
	w.short_name                workspace,
	a.id                        application_id,
	a.security_group_id         workspace_id,
	a.name                      application_name,
	a.OWNER,
	a.DESCRIPTION,
	a.STATUS,
	a.LOGIN_URL,
	a.LOGOUT_URL,
	a.HOME_PAGE_ID,
	a.AUTH_ID,
	a.ACL_TYPE,
	a.DATE_FORMAT,
	a.language,
	a.territory,
	a.LOGO_TYPE,
	a.LOGO_TEXT,
	a.LOGO_TEXT_ATTRIBUTES,
	dbms_lob.getlength(a.LOGO_IMAGE) logo_image_size,
	a.LOGO_IMAGE_FILENAME,
	a.LOGO_IMAGE_MIMETYPE,
	a.LOGO_IMAGE_CHARSET,
	a.LOGO_IMAGE_LAST_UPDATE,
	a.LOGO_IMAGE_ATTRIBUTES,
	a.LOGO_FILEPATH,
	a.LOGO_FILEPATH_ATTRIBUTES,
	--
	a.created_on,
	a.created_by,
	a.updated_on,
	a.updated_by
from
     wwv_flow_ws_applications a,
     wwv_flow_companies w,
     wwv_flow_company_schemas s,
     (select nvl(nv('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
where (s.schema = user or user in ('SYS','SYSTEM', 'APEX_040000')  or d.sgid = w.PROVISIONING_COMPANY_ID) and
      s.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.is_apex$_schema = 'Y' and
      a.security_group_id = w.PROVISIONING_COMPANY_ID and
      w.provisioning_company_id != 0
/

