create function wwv_popup_filter return varchar2 as begin return wwv_flow.g_popup_filter; end;
/

