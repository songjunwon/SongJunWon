create view APEX_UI_DEFAULTS_GROUPS as
select t.schema,
       t.table_name,
       g.group_name,
       g.description,
       g.display_sequence,
       g.created_by,
       g.created_on,
       g.last_updated_by,
       g.last_updated_on
  from wwv_flow_hnt_groups g,
       wwv_flow_hnt_table_info t
 where t.schema   = user
   and g.table_id = t.table_id
/

comment on table APEX_UI_DEFAULTS_GROUPS is 'The User Interface Defaults for the groups within the tables in this schema.  Used by the wizards when generating applications.'
/

comment on column APEX_UI_DEFAULTS_GROUPS.SCHEMA is 'Schema owning table.'
/

comment on column APEX_UI_DEFAULTS_GROUPS.TABLE_NAME is 'Name of table in the schema.'
/

comment on column APEX_UI_DEFAULTS_GROUPS.GROUP_NAME is 'When creating a form based upon this table, this will be used to group columns together into regions and this will be used as the region title.  When creating an interactive report against this table, this will be used to group the columns together and this will be used as the group name.'
/

comment on column APEX_UI_DEFAULTS_GROUPS.DESCRIPTION is 'Description of the group.  Not used during generation.'
/

comment on column APEX_UI_DEFAULTS_GROUPS.DISPLAY_SEQUENCE is 'Used to provide sequence of regions within a form and groups within an interactive report.'
/

comment on column APEX_UI_DEFAULTS_GROUPS.CREATED_BY is 'Auditing; user that created the record.'
/

comment on column APEX_UI_DEFAULTS_GROUPS.CREATED_ON is 'Auditing; date the record was created.'
/

comment on column APEX_UI_DEFAULTS_GROUPS.LAST_UPDATED_BY is 'Auditing; user that last modified the record.'
/

comment on column APEX_UI_DEFAULTS_GROUPS.LAST_UPDATED_ON is 'Auditing; date the record was last modified.'
/

