create view APEX_APPLICATION_GROUPS as
select
    w.short_name                 workspace,
    g.ID                         application_group_id,
    g.group_name                 group_name,
    g.group_comment              group_comment,
    w.PROVISIONING_COMPANY_ID    workspace_id
from
     wwv_flow_companies w,
     wwv_flow_company_schemas s,
     wwv_flow_application_groups g,
     (select nvl(nv('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
where (s.schema = user or user in ('SYS','SYSTEM', 'APEX_040000')  or d.sgid = w.PROVISIONING_COMPANY_ID) and
      s.security_group_id = w.PROVISIONING_COMPANY_ID and
      w.PROVISIONING_COMPANY_ID != 0  and
      w.PROVISIONING_COMPANY_ID = g.security_group_id
group by  w.PROVISIONING_COMPANY_ID, w.short_name, w.FIRST_SCHEMA_PROVISIONED,g.id, g.group_name, g.group_comment
/

comment on table APEX_APPLICATION_GROUPS is 'Application Groups defined per workspace.  Applications can be associated with an application group.'
/

comment on column APEX_APPLICATION_GROUPS.WORKSPACE is 'A work area mapped to one or more database schemas'
/

comment on column APEX_APPLICATION_GROUPS.APPLICATION_GROUP_ID is 'Identifies the ID of the application group this application is associated with'
/

comment on column APEX_APPLICATION_GROUPS.GROUP_NAME is 'Identifies the application group'
/

comment on column APEX_APPLICATION_GROUPS.GROUP_COMMENT is 'Identifies comments for a given application group'
/

